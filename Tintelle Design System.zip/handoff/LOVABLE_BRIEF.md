# Brief for Lovable (or any AI coding tool)

You are rebuilding the Tintelle storefront from this design specification. Every visual decision, every page, every interaction is already designed and working in this repo. **Your job is to re-implement it in production code without changing the design.**

---

## Read these first, in order

1. `README.md` — file map and conventions
2. `index.html` — open in a browser to see the homepage
3. `pages/*.html` — open each one in a browser to see every page
4. `design-system/README.md` — the brand + design system documentation
5. `colors_and_type.css` — the design tokens
6. `components/Chrome.jsx` — the shared chrome (header, footer, stores, products)

---

## Hard rules — do not deviate

### Visual design
- **Every color comes from `colors_and_type.css`.** Do not introduce new colors. Map `--primary`, `--deep-mauve`, `--rose-taupe`, `--warm-cream`, `--cloud`, `--accent`, `--soft-ivory`, `--fg` into your design tokens (Tailwind theme, CSS vars, whatever your stack uses).
- **Two fonts only:** Cormorant Garamond (serif, headlines + prices) and Inter (sans, UI + body). Both are loaded from Google Fonts in `colors_and_type.css`.
- **Eyebrow labels are 11px, 0.3em letter-spacing, uppercase, `--rose-taupe`.** Used everywhere above headlines.
- **Headlines use Cormorant 500 weight,** never bold, with -0.01em letter-spacing on large sizes.
- **No emoji. No gradients. No drop shadows on cards** — borders only (`1px solid var(--cloud)`).
- **No rounded corners on UI.** Buttons, inputs, cards are square. Pills only on tag chips and the cart count badge.

### Layout
- **Max content width is 1280px** (`max-width: 1280px; margin: 0 auto; padding: 0 24px;`).
- **Page top padding is 72px on hero sections, 96px on inner pages.**
- **Grid columns: 4-up for product grids, 3-up for editorial, 2-up for PDP / about hero.**

### Interactions
- **Cart and wishlist are localStorage-backed** with a custom event for sync. Re-implement that pattern in your state library (Zustand, Redux, etc.) — the API is `cartStore.add/setQty/remove` and `wishlistStore.toggle/has`.
- **Cart persists across page navigations.** Verify this works in your build.
- **PDP shade picker is a row of color circles.** Selected shade is `2px solid var(--deep-mauve)`, others `1px solid var(--cloud)`.
- **Subscribe & Save shows 15% off.** Recurring billing logic should match what's in `pages/subscribe.html`.

### Copy
- **Do not rewrite copy.** Headlines, body, eyebrows, CTAs are all final and approved. Lift them verbatim.
- **Tagline:** "Skincare that shows. Color that cares."
- **Tone:** confident, intimate, low-fluff. Closer to a print editorial than a Shopify default theme.

### Pages — implement all 17
Homepage + 16 inner pages. See `README.md` for the table.

### Assets
- 7 images in `assets/` are final art. Use them as-is.
- The logo (`tintelle-logo.png`) is rendered as a wordmark in CSS — `font-family: var(--font-serif); letter-spacing: 0.25em; font-size: 28px;`. The PNG is for fallback/social only.

---

## Suggested stack mapping

| This repo uses | Lovable / Next.js / Hydrogen target |
|---|---|
| Inline Babel React | `.tsx` components in `app/` or `components/` |
| `<a href="pages/foo.html">` | `<Link href="/foo">` (file-based routing) |
| `pdp.html?id=skin-tint` | `/products/[handle]` dynamic route |
| `post.html?slug=...` | `/journal/[slug]` dynamic route |
| `window.cartStore` (localStorage) | Zustand store + Shopify Cart API |
| `window.wishlistStore` (localStorage) | Customer metafield or browser localStorage hook |
| `window.PRODUCTS` (hardcoded) | Shopify Storefront API `products` query |
| `window.JOURNAL_FEED` (hardcoded) | CMS (Contentful / Sanity / Shopify Articles) |
| `colors_and_type.css` vars | `tailwind.config.ts` `theme.extend.colors` + `fontFamily` |

---

## Component checklist

These all exist in `components/`. Re-implement each one:

- [ ] `Header` (with nav, logo wordmark, search/wishlist/account/cart icons + cart count badge)
- [ ] `Footer` (newsletter signup + 3 link columns + copyright + tagline)
- [ ] `AnnouncementBar` (top, full-width, primary background)
- [ ] `Hero` (homepage 2-up split with image and headline + 2 CTAs)
- [ ] `Bestsellers` (4-up product grid section)
- [ ] `ProductCard` (image, eyebrow, title, price, hover state)
- [ ] `ShopByConcern` (4 concern cards with images, links to filtered shop)
- [ ] `RoutineUpsell` (bundle promo section)
- [ ] `TrustBanner` (icons + claims row)
- [ ] `CartDrawer` (slide-in cart from header — also implemented as full page in `cart.html`)
- [ ] PDP: gallery, shade picker, qty stepper, add-to-bag, wishlist heart, ingredients accordion, cross-sell
- [ ] Search: debounced input, multi-section results (Products / Journal / Help), URL-synced query
- [ ] Subscribe: product picker, frequency selector, summary card, FAQ accordion
- [ ] Track: order ID + email form, 5-stage status bar, activity timeline, items + totals sidebar
- [ ] Wishlist: 4-up grid with remove + add-to-bag, designed empty state
- [ ] Journal: feed reader with category tabs + search input + featured post + grid
- [ ] Post: block renderer for `paragraph / heading / quote / list / image`, related products, keep-reading rail
- [ ] Cart: 4-step checkout (cart → shipping → payment → confirmation)
- [ ] Account: sign-in / sign-up / dashboard with tabs
- [ ] Privacy / Terms: sticky-TOC two-column layout
- [ ] Shipping / FAQ / Contact / About: standard editorial page layout

---

## What to ask the project owner

Before integration, confirm:
1. **Which e-commerce platform?** Shopify? Stripe? Custom? — affects cart, checkout, subscriptions, and product data.
2. **Which CMS for the Journal?** Shopify Articles, Contentful, Sanity, or stay file-based?
3. **Real product catalog** — the 5 SKUs here are placeholder; production needs real inventory/variants.
4. **Subscription provider** — Recharge, Stay, native Shopify Subscriptions, or custom?
5. **Order tracking integration** — Shopify Fulfillment API, ShipStation, AfterShip?
6. **Newsletter / email** — Klaviyo? Mailchimp? — for the footer signup.
7. **Customer accounts** — Shopify Customer Accounts, Auth0, Clerk?
8. **Analytics / pixels** — GA4, Meta Pixel, etc.

---

## What you should not do

- ❌ Don't add new pages, components, or sections without checking with the owner.
- ❌ Don't change copy, headlines, or button labels.
- ❌ Don't add gradients, glassmorphism, drop shadows, neon, or any "modern SaaS" treatment.
- ❌ Don't introduce a new color, even a shade-darker version of an existing one. Use the tokens.
- ❌ Don't substitute fonts. Cormorant Garamond + Inter only.
- ❌ Don't replace the wordmark logo with the PNG. The wordmark is the logo.

---

## What you should do

- ✅ Match every page pixel-for-pixel.
- ✅ Re-use the design tokens — never hardcode colors or spacing.
- ✅ Keep accessibility: aria-labels on icon buttons, semantic HTML, color contrast meets WCAG AA.
- ✅ Make it responsive — the source is desktop-first; add mobile breakpoints at `768px` and `480px`. Stack 4-up grids to 2-up on tablet, 1-up on mobile.
- ✅ Add real loading and error states where this design has none (search, journal fetch, product fetch).
- ✅ Optimize images via your stack's image component (`next/image`, Hydrogen `Image`, etc.) — don't ship the raw JPEGs in production.

---

If you stay inside the rules above, the result will be Tintelle. Ship it.
