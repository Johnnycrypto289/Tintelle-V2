function RoutineUpsell({ onAdd }) {
  const bundle = { id: 'routine', title: 'The Tintelle Routine', eyebrow: 'Bundle', price: 75, img: '../assets/tintelle-routine.jpg' };
  return (
    <section id="routine" style={{ padding: '96px 0', background: 'var(--soft-ivory)' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 24px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 64, alignItems: 'center' }}>
        <div style={{ aspectRatio: '5/4', overflow: 'hidden', background: 'var(--warm-cream)' }}>
          <img src={bundle.img} alt="The Tintelle Routine" style={{ width: '100%', height: '100%', objectFit: 'cover' }}/>
        </div>
        <div>
          <p style={{ fontSize: 12, letterSpacing: '0.3em', textTransform: 'uppercase', color: 'var(--rose-taupe)', margin: 0 }}>The Routine</p>
          <h2 style={{ fontFamily: 'var(--font-serif)', fontWeight: 500, fontSize: 48, lineHeight: 1.1, color: 'var(--deep-mauve)', margin: '20px 0' }}>
            The complete look in three steps.
          </h2>
          <p style={{ color: 'var(--rose-taupe)', maxWidth: 440, lineHeight: 1.6, margin: '0 0 24px' }}>
            Skin Tint. Lip Tint. Cheek Tint. The effortless trio our routine is built around — bundled at a softer price.
          </p>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, marginBottom: 24 }}>
            <span style={{ fontFamily: 'var(--font-serif)', fontSize: 28, color: 'var(--deep-mauve)' }}>$75.00</span>
            <span style={{ fontSize: 14, textDecoration: 'line-through', color: 'var(--rose-taupe)' }}>$90</span>
          </div>
          <button onClick={() => onAdd(bundle)} style={{
            padding: '14px 32px', height: 48, fontSize: 12, letterSpacing: '0.18em',
            textTransform: 'uppercase', background: 'var(--primary)', color: '#fff', border: 0, cursor: 'pointer',
            fontFamily: 'var(--font-sans)'
          }}>Shop the Set</button>
        </div>
      </div>
    </section>
  );
}
window.RoutineUpsell = RoutineUpsell;
