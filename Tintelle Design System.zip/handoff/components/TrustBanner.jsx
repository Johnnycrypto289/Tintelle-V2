function TrustBanner() {
  const items = [
    { icon: 'shield-check', label: 'Dermatologist Tested', body: 'Formulated and reviewed by board-certified dermatologists.' },
    { icon: 'leaf', label: 'Clean & Vegan', body: 'Plant-based, cruelty-free, never silicones or parabens.' },
    { icon: 'sparkles', label: '30-Day Shade Match', body: 'Find your shade — or send it back, no questions asked.' }
  ];
  return (
    <section style={{ background: 'var(--warm-cream)', padding: '80px 0' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 24px', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 48, textAlign: 'center' }}>
        {items.map(it => (
          <div key={it.label}>
            <i data-lucide={it.icon} strokeWidth="1.5" width="32" height="32" style={{ color: 'var(--accent)' }}></i>
            <h3 style={{ fontFamily: 'var(--font-serif)', fontWeight: 500, fontSize: 22, color: 'var(--deep-mauve)', margin: '12px 0 8px' }}>{it.label}</h3>
            <p style={{ fontSize: 14, color: 'var(--rose-taupe)', maxWidth: 280, margin: '0 auto', lineHeight: 1.6 }}>{it.body}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
window.TrustBanner = TrustBanner;
