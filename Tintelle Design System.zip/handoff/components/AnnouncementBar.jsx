function AnnouncementBar() {
  return (
    <div style={{
      background: 'var(--primary)', color: '#fff', textAlign: 'center',
      padding: '10px 12px', fontSize: 11, letterSpacing: '0.2em',
      textTransform: 'uppercase', fontFamily: 'var(--font-sans)'
    }}>
      Free shipping on orders over $50 · Clean · Vegan · Cruelty-Free
    </div>
  );
}
window.AnnouncementBar = AnnouncementBar;
