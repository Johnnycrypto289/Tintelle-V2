const PRODUCTS = [
  { id: 'skin-tint', eyebrow: 'Skin Tint', title: 'Skin Tint SPF 30', price: 38, img: '../assets/product-skin-tint.jpg' },
  { id: 'lip-tint',  eyebrow: 'Lip Tint',  title: 'Peptide Lip Tint', price: 24, img: '../assets/product-lip-tint.jpg' },
  { id: 'cheek-tint',eyebrow: 'Cheek Tint',title: 'Glow Cheek Tint',  price: 28, img: '../assets/product-cheek-tint.jpg' },
  { id: 'eye-serum', eyebrow: 'Eye Serum', title: 'Tinted Eye Serum', price: 32, img: '../assets/product-eye-serum.jpg' }
];

function App() {
  const [cart, setCart] = React.useState([]);
  const [open, setOpen] = React.useState(false);

  const addItem = (p) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === p.id);
      if (existing) return prev.map(i => i.id === p.id ? { ...i, qty: i.qty + 1 } : i);
      return [...prev, { id: p.id, title: p.title, price: p.price, img: p.img, qty: 1 }];
    });
    setOpen(true);
    setTimeout(() => window.lucide && window.lucide.createIcons(), 30);
  };
  const changeQty = (id, qty) => setCart(prev => prev.map(i => i.id === id ? { ...i, qty } : i));
  const remove = (id) => setCart(prev => prev.filter(i => i.id !== id));

  React.useEffect(() => { if (window.lucide) window.lucide.createIcons(); }, [cart, open]);

  const cartCount = cart.reduce((s, i) => s + i.qty, 0);

  return (
    <>
      <AnnouncementBar />
      <Header cartCount={cartCount} onOpenCart={() => setOpen(true)} />
      <Hero />
      <ShopByConcern />
      <Bestsellers products={PRODUCTS} onAdd={addItem} />
      <TrustBanner />
      <RoutineUpsell onAdd={addItem} />
      <Footer />
      <CartDrawer open={open} items={cart} onClose={() => setOpen(false)} onChangeQty={changeQty} onRemove={remove} />
    </>
  );
}
window.App = App;
