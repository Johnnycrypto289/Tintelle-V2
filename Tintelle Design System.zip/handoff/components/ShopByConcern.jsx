function ShopByConcern() {
  const concerns = [
    { label: 'Even Skin Tone', color: 'var(--petal-pink)' },
    { label: 'Hydrate Lips', color: 'var(--soft-coral)' },
    { label: 'Add a Flush', color: 'var(--primary)' },
    { label: 'Brighten Eyes', color: 'var(--sage-mist)' }
  ];
  return (
    <section style={{ padding: '96px 0' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 24px' }}>
        <div style={{ textAlign: 'center', maxWidth: 580, margin: '0 auto 48px' }}>
          <p style={{ fontSize: 12, letterSpacing: '0.3em', textTransform: 'uppercase', color: 'var(--rose-taupe)', margin: 0 }}>Shop by concern</p>
          <h2 style={{ fontFamily: 'var(--font-serif)', fontWeight: 500, fontSize: 40, color: 'var(--deep-mauve)', margin: '12px 0 0' }}>Find Your Tint</h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 48 }}>
          {concerns.map(c => (
            <a key={c.label} href="pages/shop.html" className="concern" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16, cursor: 'pointer', textDecoration: 'none' }}>
              <div className="concern-thumb" style={{ background: c.color, aspectRatio: '1 / 1', width: 160, borderRadius: 999, transition: 'transform .5s cubic-bezier(.22,.61,.36,1)' }} />
              <span style={{ fontFamily: 'var(--font-serif)', color: 'var(--deep-mauve)', fontSize: 18 }}>{c.label}</span>
            </a>
          ))}
        </div>
      </div>
      <style>{`.concern:hover .concern-thumb{transform:scale(1.05);}`}</style>
    </section>
  );
}
window.ShopByConcern = ShopByConcern;
