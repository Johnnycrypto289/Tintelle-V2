function Footer() {
  const cols = [
    { title: 'Shop', links: [['All Products','pages/shop.html'],['Best Sellers','pages/shop.html'],['The Routine','#routine'],['Subscribe & Save','pages/subscribe.html'],['Gift Cards','pages/shop.html']] },
    { title: 'About', links: [['Our Story','pages/about.html'],['Ingredients','pages/about.html'],['Sustainability','pages/about.html'],['Journal','pages/journal.html']] },
    { title: 'Support', links: [['Contact','pages/contact.html'],['FAQ','pages/faq.html'],['Track Order','pages/track.html'],['Wishlist','pages/wishlist.html'],['Shipping & Returns','pages/shipping.html'],['Privacy Policy','pages/privacy.html'],['Terms','pages/terms.html']] }
  ];
  return (
    <footer style={{ background: 'var(--warm-cream)', padding: '64px 0 32px', marginTop: 32 }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 24px', display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 48 }}>
        <div>
          <p style={{ fontFamily: 'var(--font-serif)', fontWeight: 500, fontSize: 24, letterSpacing: '0.25em', color: 'var(--deep-mauve)', margin: 0 }}>TINTELLE</p>
          <p style={{ fontSize: 14, color: 'var(--rose-taupe)', lineHeight: 1.6, margin: '16px 0 16px', maxWidth: 280 }}>
            Join the Tintelle Community. Get early access to drops, shade guides, and skin-first rituals.
          </p>
          <form onSubmit={(e) => e.preventDefault()} style={{ display: 'flex', gap: 8 }}>
            <input type="email" placeholder="Enter your email" style={{
              flex: 1, padding: '12px 14px', background: 'var(--soft-ivory)', border: '1px solid rgba(107,76,76,0.3)',
              borderRadius: 0, fontSize: 13, color: 'var(--fg)', fontFamily: 'var(--font-sans)', outline: 'none'
            }}/>
            <button type="submit" style={{
              padding: '12px 18px', fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase',
              background: 'var(--primary)', color: '#fff', border: 0, cursor: 'pointer', fontFamily: 'var(--font-sans)'
            }}>Join</button>
          </form>
        </div>
        {cols.map(col => (
          <div key={col.title}>
            <h4 style={{ fontFamily: 'var(--font-serif)', fontWeight: 500, color: 'var(--deep-mauve)', fontSize: 18, margin: '0 0 16px' }}>{col.title}</h4>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
              {col.links.map(([l,href]) => (
                <li key={l}><a href={href} style={{ color: 'var(--rose-taupe)', fontSize: 14, textDecoration: 'none', cursor: 'pointer' }}>{l}</a></li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div style={{ maxWidth: 1280, margin: '48px auto 0', padding: '24px 24px 0', borderTop: '1px solid rgba(232,226,220,0.7)', display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--rose-taupe)' }}>
        <p style={{margin:0}}>© 2026 Tintelle. All rights reserved.</p>
        <p style={{margin:0}}>Skincare that shows. Color that cares.</p>
      </div>
    </footer>
  );
}
window.Footer = Footer;
