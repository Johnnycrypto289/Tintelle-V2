function Header({ cartCount, onOpenCart }) {
  const linkStyle = { color: 'var(--deep-mauve)', textDecoration: 'none', fontSize: 14, transition: 'color .3s', cursor: 'pointer' };
  const iconBtn = { background: 'transparent', border: 0, padding: 8, color: 'var(--deep-mauve)', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', position: 'relative' };
  return (
    <header style={{
      position: 'sticky', top: 0, zIndex: 40,
      background: 'rgba(251,248,244,0.85)', backdropFilter: 'blur(12px)',
      borderBottom: '1px solid rgba(232,226,220,0.6)'
    }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 24px', height: 80, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <nav style={{ display: 'flex', gap: 40, flex: 1 }}>
          <a href="pages/shop.html" style={linkStyle}>Shop</a>
          <a href="pages/about.html" style={linkStyle}>About</a>
          <a href="#routine" style={linkStyle}>Routine</a>
          <a href="pages/journal.html" style={linkStyle}>Journal</a>
        </nav>
        <a href="index.html" style={{
          fontFamily: 'var(--font-serif)', fontWeight: 500, fontSize: 28,
          letterSpacing: '0.25em', color: 'var(--deep-mauve)', flex: 1, textAlign: 'center', textDecoration: 'none'
        }}>TINTELLE</a>
        <div style={{ display: 'flex', gap: 4, flex: 1, justifyContent: 'flex-end', alignItems: 'center' }}>
          <a href="pages/search.html" style={iconBtn} aria-label="Search"><i data-lucide="search" strokeWidth="1.5" width="20" height="20"></i></a>
          <a href="pages/wishlist.html" style={iconBtn} aria-label="Wishlist"><i data-lucide="heart" strokeWidth="1.5" width="20" height="20"></i></a>
          <a href="pages/account.html" style={iconBtn} aria-label="Account"><i data-lucide="user" strokeWidth="1.5" width="20" height="20"></i></a>
          <button style={iconBtn} aria-label="Cart" onClick={onOpenCart}>
            <i data-lucide="shopping-bag" strokeWidth="1.5" width="20" height="20"></i>
            {cartCount > 0 && (
              <span style={{ position: 'absolute', top: 4, right: 2, background: 'var(--primary)', color: '#fff', fontSize: 9, padding: '2px 5px', borderRadius: 999, fontFamily: 'var(--font-sans)' }}>{cartCount}</span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
window.Header = Header;
