function CartDrawer({ open, items, onClose, onChangeQty, onRemove }) {
  const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0);
  return (
    <>
      <div onClick={onClose} style={{
        position: 'fixed', inset: 0, background: 'rgba(45,41,38,0.45)',
        opacity: open ? 1 : 0, pointerEvents: open ? 'auto' : 'none',
        transition: 'opacity .3s', zIndex: 50
      }}/>
      <aside style={{
        position: 'fixed', top: 0, right: 0, height: '100vh', width: 420, maxWidth: '100%',
        background: 'var(--soft-ivory)', boxShadow: '0 20px 60px rgba(107,76,76,.12)',
        transform: open ? 'translateX(0)' : 'translateX(100%)',
        transition: 'transform .35s cubic-bezier(.22,.61,.36,1)',
        display: 'flex', flexDirection: 'column', zIndex: 60
      }}>
        <div style={{ padding: '24px', borderBottom: '1px solid var(--cloud)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <p style={{ fontSize: 11, letterSpacing: '0.3em', textTransform: 'uppercase', color: 'var(--rose-taupe)', margin: 0 }}>Your Bag</p>
          <button onClick={onClose} style={{ background: 'transparent', border: 0, padding: 6, cursor: 'pointer', color: 'var(--deep-mauve)' }}>
            <i data-lucide="x" strokeWidth="1.5" width="20" height="20"></i>
          </button>
        </div>
        <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
          {items.length === 0 ? (
            <p style={{ fontFamily: 'var(--font-serif)', color: 'var(--rose-taupe)', fontSize: 18, textAlign: 'center', marginTop: 60 }}>Your bag is empty.</p>
          ) : items.map(it => (
            <div key={it.id} style={{ display: 'grid', gridTemplateColumns: '64px 1fr auto', gap: 14, marginBottom: 18, paddingBottom: 18, borderBottom: '1px solid var(--cloud)' }}>
              <div style={{ width: 64, height: 64, background: 'var(--warm-cream)', overflow: 'hidden' }}>
                <img src={it.img} style={{width:'100%',height:'100%',objectFit:'cover'}}/>
              </div>
              <div>
                <p style={{ fontFamily: 'var(--font-serif)', color: 'var(--deep-mauve)', fontSize: 15, margin: 0 }}>{it.title}</p>
                <p style={{ fontSize: 13, color: 'var(--rose-taupe)', margin: '4px 0 8px' }}>${it.price.toFixed(2)}</p>
                <div style={{ display: 'inline-flex', alignItems: 'center', border: '1px solid var(--cloud)' }}>
                  <button style={qtyBtn} onClick={() => onChangeQty(it.id, Math.max(1, it.qty - 1))}>−</button>
                  <span style={{ padding: '0 10px', fontSize: 13, color: 'var(--deep-mauve)' }}>{it.qty}</span>
                  <button style={qtyBtn} onClick={() => onChangeQty(it.id, it.qty + 1)}>+</button>
                </div>
              </div>
              <button onClick={() => onRemove(it.id)} style={{ background: 'transparent', border: 0, color: 'var(--rose-taupe)', cursor: 'pointer', fontSize: 11, letterSpacing: '0.2em', textTransform: 'uppercase', alignSelf: 'flex-start' }}>Remove</button>
            </div>
          ))}
        </div>
        <div style={{ padding: 24, borderTop: '1px solid var(--cloud)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
            <span style={{ fontFamily: 'var(--font-serif)', fontSize: 18, color: 'var(--deep-mauve)' }}>Subtotal</span>
            <span style={{ fontFamily: 'var(--font-serif)', fontSize: 18, color: 'var(--deep-mauve)' }}>${subtotal.toFixed(2)}</span>
          </div>
          <button style={{
            width: '100%', padding: 16, fontSize: 12, letterSpacing: '0.18em',
            textTransform: 'uppercase', background: 'var(--primary)', color: '#fff', border: 0, cursor: 'pointer',
            fontFamily: 'var(--font-sans)'
          }} disabled={items.length === 0}>Checkout</button>
        </div>
      </aside>
    </>
  );
}
const qtyBtn = { background: 'transparent', border: 0, padding: '6px 10px', color: 'var(--deep-mauve)', cursor: 'pointer', fontSize: 14 };
window.CartDrawer = CartDrawer;
