function ProductCard({ product, onAdd }) {
  const pdp = `pages/pdp.html?id=${product.id}`;
  return (
    <div className="pcard" style={{
      background: '#fff', border: '1px solid rgba(232,226,220,0.7)',
      transition: 'border-color .3s', cursor: 'pointer'
    }}>
      <a href={pdp} style={{display:'block', aspectRatio: '1/1', background: 'var(--warm-cream)', overflow: 'hidden' }}>
        <img src={product.img} alt={product.title} className="pcard-img" style={{ width:'100%', height:'100%', objectFit:'cover', transition: 'transform .7s cubic-bezier(.22,.61,.36,1)' }}/>
      </a>
      <div style={{ padding: '20px 20px 24px', textAlign: 'center' }}>
        <p style={{ fontSize: 10, letterSpacing: '0.3em', textTransform: 'uppercase', color: 'var(--rose-taupe)', margin: 0 }}>{product.eyebrow}</p>
        <a href={pdp} style={{textDecoration:'none'}}><h3 style={{ fontFamily: 'var(--font-serif)', fontWeight: 500, fontSize: 20, color: 'var(--deep-mauve)', margin: '8px 0 4px' }}>{product.title}</h3></a>
        <p style={{ fontFamily: 'var(--font-serif)', fontSize: 16, color: 'var(--deep-mauve)', margin: 0 }}>${product.price.toFixed(2)}</p>
        <button onClick={(e) => { e.stopPropagation(); onAdd(product); }} style={{
          width: '100%', marginTop: 16, padding: 12, fontSize: 11, letterSpacing: '0.18em',
          textTransform: 'uppercase', background: 'transparent', border: '1px solid var(--deep-mauve)',
          color: 'var(--deep-mauve)', cursor: 'pointer', fontFamily: 'var(--font-sans)', transition: 'all .3s'
        }}
        onMouseEnter={(e) => { e.currentTarget.style.background = 'var(--deep-mauve)'; e.currentTarget.style.color = 'var(--soft-ivory)'; }}
        onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'var(--deep-mauve)'; }}
        >Add to Bag</button>
      </div>
      <style>{`.pcard:hover{border-color:rgba(212,160,160,0.4);} .pcard:hover .pcard-img{transform:scale(1.03);}`}</style>
    </div>
  );
}
window.ProductCard = ProductCard;
