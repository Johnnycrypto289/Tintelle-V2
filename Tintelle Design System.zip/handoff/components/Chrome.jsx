// Shared chrome — Header + Footer + AnnouncementBar — usable on every page.
// Path-aware so links work whether you're at index.html or pages/foo.html.

function pathPrefix() {
  // returns '' if at storefront root, '../' if inside pages/
  return window.location.pathname.includes('/pages/') ? '../' : '';
}
window.pathPrefix = pathPrefix;

function PageAnnouncementBar() {
  return (
    <div style={{
      background: 'var(--primary)', color: '#fff', textAlign: 'center',
      padding: '10px 12px', fontSize: 11, letterSpacing: '0.2em',
      textTransform: 'uppercase', fontFamily: 'var(--font-sans)'
    }}>
      Free shipping on orders over $50 · Clean · Vegan · Cruelty-Free
    </div>
  );
}
window.PageAnnouncementBar = PageAnnouncementBar;

function PageHeader({ cartCount = 0, onOpenCart, current }) {
  const p = pathPrefix();
  const link = (label, href) => (
    <a href={p + href} className="hdrlink" style={{
      color: current === label ? 'var(--primary)' : 'var(--deep-mauve)',
      textDecoration: 'none', fontSize: 14, transition: 'color .3s', cursor: 'pointer'
    }}>{label}</a>
  );
  const iconBtn = { background: 'transparent', border: 0, padding: 8, color: 'var(--deep-mauve)', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', position: 'relative' };
  return (
    <header style={{
      position: 'sticky', top: 0, zIndex: 40,
      background: 'rgba(251,248,244,0.85)', backdropFilter: 'blur(12px)',
      borderBottom: '1px solid rgba(232,226,220,0.6)'
    }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 24px', height: 80, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <nav style={{ display: 'flex', gap: 36, flex: 1 }}>
          {link('Shop', 'pages/shop.html')}
          {link('About', 'pages/about.html')}
          {link('Routine', 'index.html#routine')}
          {link('Journal', 'pages/journal.html')}
        </nav>
        <a href={p + 'index.html'} style={{
          fontFamily: 'var(--font-serif)', fontWeight: 500, fontSize: 28,
          letterSpacing: '0.25em', color: 'var(--deep-mauve)', flex: 1, textAlign: 'center', textDecoration: 'none'
        }}>TINTELLE</a>
        <div style={{ display: 'flex', gap: 4, flex: 1, justifyContent: 'flex-end', alignItems: 'center' }}>
          <a href={p + 'pages/search.html'} style={iconBtn} aria-label="Search"><i data-lucide="search" strokeWidth="1.5" width="20" height="20"></i></a>
          <a href={p + 'pages/wishlist.html'} style={iconBtn} aria-label="Wishlist"><i data-lucide="heart" strokeWidth="1.5" width="20" height="20"></i></a>
          <a href={p + 'pages/account.html'} style={iconBtn} aria-label="Account"><i data-lucide="user" strokeWidth="1.5" width="20" height="20"></i></a>
          <a href={p + 'pages/cart.html'} style={iconBtn} aria-label="Cart">
            <i data-lucide="shopping-bag" strokeWidth="1.5" width="20" height="20"></i>
            {cartCount > 0 && (
              <span style={{ position: 'absolute', top: 4, right: 2, background: 'var(--primary)', color: '#fff', fontSize: 9, padding: '2px 5px', borderRadius: 999 }}>{cartCount}</span>
            )}
          </a>
        </div>
      </div>
      <style>{`.hdrlink:hover{color:var(--primary)!important;}`}</style>
    </header>
  );
}
window.PageHeader = PageHeader;

function PageFooter() {
  const p = pathPrefix();
  const cols = [
    { title: 'Shop', links: [['All Products','pages/shop.html'],['Best Sellers','pages/shop.html'],['The Routine','index.html#routine'],['Subscribe & Save','pages/subscribe.html'],['Gift Cards','pages/shop.html']] },
    { title: 'About', links: [['Our Story','pages/about.html'],['Ingredients','pages/about.html'],['Sustainability','pages/about.html'],['Journal','pages/journal.html']] },
    { title: 'Support', links: [['Contact','pages/contact.html'],['FAQ','pages/faq.html'],['Track Order','pages/track.html'],['Wishlist','pages/wishlist.html'],['Shipping & Returns','pages/shipping.html'],['Privacy Policy','pages/privacy.html'],['Terms','pages/terms.html']] }
  ];
  return (
    <footer style={{ background: 'var(--warm-cream)', padding: '64px 0 32px', marginTop: 32 }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 24px', display: 'grid', gridTemplateColumns: '1.4fr repeat(3, 1fr)', gap: 48 }}>
        <div>
          <p style={{ fontFamily: 'var(--font-serif)', fontWeight: 500, fontSize: 24, letterSpacing: '0.25em', color: 'var(--deep-mauve)', margin: 0 }}>TINTELLE</p>
          <p style={{ fontSize: 14, color: 'var(--rose-taupe)', lineHeight: 1.6, margin: '16px 0 16px', maxWidth: 320 }}>
            Join the Tintelle Community. Get early access to drops, shade guides, and skin-first rituals.
          </p>
          <form onSubmit={(e) => e.preventDefault()} style={{ display: 'flex', gap: 8, maxWidth: 360 }}>
            <input type="email" placeholder="Enter your email" style={{
              flex: 1, padding: '12px 14px', background: 'var(--soft-ivory)', border: '1px solid rgba(107,76,76,0.3)',
              borderRadius: 0, fontSize: 13, color: 'var(--fg)', fontFamily: 'var(--font-sans)', outline: 'none'
            }}/>
            <button type="submit" style={{
              padding: '12px 18px', fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase',
              background: 'var(--primary)', color: '#fff', border: 0, cursor: 'pointer', fontFamily: 'var(--font-sans)'
            }}>Join</button>
          </form>
        </div>
        {cols.map(col => (
          <div key={col.title}>
            <h4 style={{ fontFamily: 'var(--font-serif)', fontWeight: 500, color: 'var(--deep-mauve)', fontSize: 18, margin: '0 0 16px' }}>{col.title}</h4>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
              {col.links.map(([l, href]) => (
                <li key={l}><a className="ftlink" href={p + href} style={{ color: 'var(--rose-taupe)', fontSize: 14, textDecoration: 'none', cursor: 'pointer', transition: 'color .3s' }}>{l}</a></li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div style={{ maxWidth: 1280, margin: '48px auto 0', padding: '24px 24px 0', borderTop: '1px solid rgba(232,226,220,0.7)', display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--rose-taupe)', flexWrap: 'wrap', gap: 8 }}>
        <p style={{margin:0}}>© 2026 Tintelle. All rights reserved.</p>
        <p style={{margin:0,fontStyle:'italic'}}>Skincare that shows. Color that cares.</p>
      </div>
      <style>{`.ftlink:hover{color:var(--primary)!important;}`}</style>
    </footer>
  );
}
window.PageFooter = PageFooter;

// Shared cart store — localStorage-backed so the bag persists across pages.
window.cartStore = {
  get() { try { return JSON.parse(localStorage.getItem('tintelle_cart') || '[]'); } catch { return []; } },
  set(items) { localStorage.setItem('tintelle_cart', JSON.stringify(items)); window.dispatchEvent(new Event('cart:change')); },
  add(p) {
    const items = this.get();
    const ex = items.find(i => i.id === p.id);
    if (ex) ex.qty += 1; else items.push({ id: p.id, title: p.title, price: p.price, img: p.img, qty: 1 });
    this.set(items);
  },
  setQty(id, qty) { const items = this.get().map(i => i.id === id ? { ...i, qty } : i); this.set(items); },
  remove(id) { this.set(this.get().filter(i => i.id !== id)); },
  count() { return this.get().reduce((s, i) => s + i.qty, 0); }
};

// Shared wishlist store — localStorage-backed.
window.wishlistStore = {
  get() { try { return JSON.parse(localStorage.getItem('tintelle_wishlist') || '[]'); } catch { return []; } },
  set(ids) { localStorage.setItem('tintelle_wishlist', JSON.stringify(ids)); window.dispatchEvent(new Event('wishlist:change')); },
  has(id) { return this.get().includes(id); },
  toggle(id) { const ids = this.get(); const i = ids.indexOf(id); if (i >= 0) ids.splice(i, 1); else ids.push(id); this.set(ids); },
  remove(id) { this.set(this.get().filter(x => x !== id)); }
};
function useWishlist() {
  const [ids, setIds] = React.useState(() => window.wishlistStore.get());
  React.useEffect(() => {
    const u = () => setIds(window.wishlistStore.get());
    window.addEventListener('wishlist:change', u);
    window.addEventListener('storage', u);
    return () => { window.removeEventListener('wishlist:change', u); window.removeEventListener('storage', u); };
  }, []);
  return ids;
}
window.useWishlist = useWishlist;

function useCart() {
  const [items, setItems] = React.useState(() => window.cartStore.get());
  React.useEffect(() => {
    const update = () => setItems(window.cartStore.get());
    window.addEventListener('cart:change', update);
    window.addEventListener('storage', update);
    return () => { window.removeEventListener('cart:change', update); window.removeEventListener('storage', update); };
  }, []);
  return items;
}
window.useCart = useCart;

// Asset URL helper: assets live at project root /assets/. The chrome is loaded from
// either ui_kits/storefront/index.html or ui_kits/storefront/pages/<page>.html.
window.assetUrl = function(name) {
  return (window.location.pathname.includes('/pages/') ? '../../assets/' : '../assets/') + name;
};

window.PRODUCTS = [
  { id: 'skin-tint',  eyebrow: 'Skin Tint',  title: 'Skin Tint SPF 30',  price: 38, img: 'product-skin-tint.jpg',  desc: 'A weightless, breathable serum foundation that evens skin tone while protecting with broad-spectrum mineral SPF.', shades: 12 },
  { id: 'lip-tint',   eyebrow: 'Lip Tint',   title: 'Peptide Lip Tint',  price: 24, img: 'product-lip-tint.jpg',   desc: 'A restorative lip treatment that plumps, hydrates with peptides, and leaves a sheer wash of glossy color.', shades: 6 },
  { id: 'cheek-tint', eyebrow: 'Cheek Tint', title: 'Glow Cheek Tint',   price: 28, img: 'product-cheek-tint.jpg', desc: 'A melting cream blush infused with squalane for a dewy, natural flush that lasts all day.', shades: 4 },
  { id: 'eye-serum',  eyebrow: 'Eye Serum',  title: 'Tinted Eye Serum',  price: 32, img: 'product-eye-serum.jpg',  desc: 'A brightening eye cream with a subtle peach tint to instantly neutralize dark circles while caffeine depuffs.', shades: 1 },
  { id: 'routine',    eyebrow: 'Bundle',     title: 'The Tintelle Routine', price: 75, img: 'tintelle-routine.jpg', desc: 'The effortless trio: Skin Tint, Lip Tint, Cheek Tint — bundled at a softer price.', shades: 1, was: 90 }
];
