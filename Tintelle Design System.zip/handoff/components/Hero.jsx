function Hero() {
  return (
    <section style={{ background: 'var(--warm-cream)' }}>
      <div style={{
        maxWidth: 1280, margin: '0 auto', padding: '96px 24px',
        display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 64, alignItems: 'center'
      }}>
        <div style={{ animation: 'fadeUp .9s cubic-bezier(.22,.61,.36,1) both' }}>
          <p style={{ fontSize: 12, letterSpacing: '0.3em', textTransform: 'uppercase', color: 'var(--rose-taupe)', margin: 0 }}>Tinted skincare, redefined</p>
          <h1 style={{
            fontFamily: 'var(--font-serif)', fontWeight: 500,
            fontSize: 72, lineHeight: 1.05, letterSpacing: '-0.01em',
            color: 'var(--deep-mauve)', margin: '24px 0 0'
          }}>
            Skincare that shows.<br/>
            <span style={{ color: 'var(--primary)', fontStyle: 'italic' }}>Color that cares.</span>
          </h1>
          <p style={{ fontSize: 18, color: 'var(--rose-taupe)', maxWidth: 440, lineHeight: 1.6, marginTop: 24 }}>
            Tinted skincare-makeup hybrids with real ingredients that deliver effortless, skin-first color.
          </p>
          <div style={{ display: 'flex', gap: 12, marginTop: 32 }}>
            <a href="pages/shop.html" style={{
              padding: '14px 32px', height: 48, fontSize: 12, letterSpacing: '0.18em', textTransform: 'uppercase',
              background: 'var(--primary)', color: '#fff', border: 0, cursor: 'pointer', fontFamily: 'var(--font-sans)',
              display:'inline-flex', alignItems:'center', textDecoration:'none'
            }}>Shop the Collection</a>
            <a href="#routine" style={{
              padding: '14px 32px', height: 48, fontSize: 12, letterSpacing: '0.18em', textTransform: 'uppercase',
              background: 'transparent', color: 'var(--deep-mauve)', border: '1px solid var(--deep-mauve)', cursor: 'pointer', fontFamily: 'var(--font-sans)',
              display:'inline-flex', alignItems:'center', textDecoration:'none'
            }}>The Routine</a>
          </div>
        </div>
        <div style={{ position: 'relative' }}>
          <div style={{ aspectRatio: '4 / 5', overflow: 'hidden' }}>
            <img src="../assets/tintelle-hero.jpg" alt="Peach silk on warm marble" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          </div>
          <div style={{
            position: 'absolute', bottom: -16, left: -16, background: 'var(--soft-ivory)',
            border: '1px solid var(--cloud)', padding: '16px 24px'
          }}>
            <p style={{ fontSize: 11, letterSpacing: '0.2em', textTransform: 'uppercase', color: 'var(--rose-taupe)', margin: 0 }}>Dermatologist-tested</p>
            <p style={{ fontFamily: 'var(--font-serif)', color: 'var(--deep-mauve)', fontSize: 18, margin: '4px 0 0' }}>Skin-first formulas</p>
          </div>
        </div>
      </div>
    </section>
  );
}
window.Hero = Hero;
