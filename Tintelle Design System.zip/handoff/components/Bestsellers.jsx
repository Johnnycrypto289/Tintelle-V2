function Bestsellers({ products, onAdd }) {
  return (
    <section id="bestsellers" style={{ padding: '96px 0', background: 'var(--soft-ivory)' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 24px' }}>
        <div style={{ textAlign: 'center', maxWidth: 580, margin: '0 auto 48px' }}>
          <p style={{ fontSize: 12, letterSpacing: '0.3em', textTransform: 'uppercase', color: 'var(--rose-taupe)', margin: 0 }}>Bestsellers</p>
          <h2 style={{ fontFamily: 'var(--font-serif)', fontWeight: 500, fontSize: 40, color: 'var(--deep-mauve)', margin: '12px 0 12px' }}>The Essentials</h2>
          <p style={{ color: 'var(--rose-taupe)', margin: 0 }}>The trio our community can't put down.</p>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 32 }}>
          {products.slice(0, 3).map(p => <ProductCard key={p.id} product={p} onAdd={onAdd}/>)}
        </div>
      </div>
    </section>
  );
}
window.Bestsellers = Bestsellers;
