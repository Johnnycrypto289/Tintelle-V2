# Tintelle Design System

> **Skincare that shows. Color that cares.**

Tintelle is a premium-accessible D2C beauty brand at the intersection of skincare and color cosmetics. Every product is a tinted skincare-makeup hybrid — Skin Tint SPF 30, Peptide Lip Tint, Glow Cheek Tint, Tinted Eye Serum — clean, vegan, cruelty-free, made in North America. The brand voice sits between **Glossier**, **Rhode**, and **Rare Beauty**: warm, intimate, ingredient-literate, never clinical.

This design system contains everything you need to design ON-brand artifacts (slides, marketing pages, product pages, ads, email, prototypes) for Tintelle.

---

## Sources used to build this system

| Source | Path | What's in it |
|---|---|---|
| Brand blueprint | `uploads/Tintelle_ Complete Brand & Shopify Store Blueprint.txt` | Positioning, palette spec, product line, store layout |
| Color palette spec | `uploads/tintelle_color_palette.png` | The full 12-swatch system (primary / secondary / neutral / functional) |
| Website mockup | `uploads/tintelle_website_mockup.png` | Reference render of the storefront |
| Wordmark | `uploads/Tintelle beauty - 2 (1).png` → `assets/tintelle-logo.png` | Master logo lockup |
| Storefront codebase | github.com/Johnnycrypto289/tintelle-shop-assist | Vite + React + shadcn/ui + Tailwind. **The pixel-level source of truth** for the storefront. |

The codebase is what's been recreated in `ui_kits/storefront/`. CSS variables in `colors_and_type.css` are derived from the `:root` block in `src/index.css` of that repo.

---

## Index

```
.
├── README.md                       ← you are here
├── SKILL.md                        ← Agent Skill manifest (cross-compatible with Claude Code)
├── colors_and_type.css             ← All design tokens as CSS vars
├── assets/                         ← Logos, product photography, hero imagery
│   ├── tintelle-logo.png           ← Master wordmark (4000×4000, transparent)
│   ├── tintelle-hero.jpg           ← Peach silk on marble — primary hero
│   ├── tintelle-routine.jpg        ← The 3-product trio shot
│   ├── product-skin-tint.jpg
│   ├── product-lip-tint.jpg
│   ├── product-cheek-tint.jpg
│   └── product-eye-serum.jpg
├── preview/                        ← Design-system cards (registered as assets)
│   ├── colors-primary.html
│   ├── colors-secondary.html
│   ├── colors-neutral.html
│   ├── colors-functional.html
│   ├── colors-semantic.html
│   ├── type-families.html
│   ├── type-scale.html
│   ├── type-eyebrow.html
│   ├── spacing-scale.html
│   ├── radii-shadows.html
│   ├── buttons.html
│   ├── product-card.html
│   ├── form-inputs.html
│   ├── badges-eyebrows.html
│   ├── icon-set.html
│   ├── logo-lockup.html
│   └── motion-states.html
└── ui_kits/
    └── storefront/                 ← Tintelle.com (Shopify-style storefront)
        ├── README.md
        ├── index.html
        └── components/             ← JSX components
```

---

## CONTENT FUNDAMENTALS

### Voice
Warm, confident, intimate — *like a best friend who happens to know skincare science*. Never clinical, never try-hard. Tintelle is the friend who actually knows what peptides do but won't lecture you about them.

Reference points: **Rhode** (minimal, knowing, lowercase confidence) **× Glossier** (community, "you, but better") **× a French accent** (a little restrained, a little romantic).

### Casing
- **Headlines (serif):** Sentence case. `Skincare that shows.` — never `SKINCARE THAT SHOWS`.
- **Eyebrows / micro-labels (sans):** UPPERCASE with **0.3em letter-spacing**. e.g. `BESTSELLERS`, `THE ROUTINE`, `TINTED SKINCARE, REDEFINED`.
- **Buttons:** UPPERCASE with **0.18em letter-spacing**. `SHOP THE COLLECTION`.
- **Body copy:** Sentence case. Always.
- **Logo:** UPPERCASE serif with **0.25em letter-spacing**. `T I N T E L L E`.

### Pronouns & POV
- **"You"** — direct, second-person. Tintelle speaks to you, not at a market.
- **"We"** — used sparingly, only when the brand itself is the actor ("We make formulas that…").
- Never "our customers," "users," or any third-person remove.
- Never imperative-y in a clinical way. Prefer *"Your skin, with a tint"* over *"Apply 1–2 pumps to clean skin."*

### Tone in three lines
> Skincare that shows. Color that cares.
> Your makeup should love your skin back.
> Effortless, skin-first color that builds with you.

### Sentence rhythm
Short. Then a longer one that explains, expands, or earns its keep. Then short again. Periods do work. Commas are romantic. Em-dashes are allowed but sparingly — not as a tic.

### What we say / what we don't
| ✅ Yes | ❌ No |
|---|---|
| skin-first, buildable, dewy, glowy, weightless, sheer | flawless, full-coverage, anti-aging, perfecting |
| peptides, squalane, SPF, broad-spectrum, vegan, clean | dermatologically-formulated synergistic complex |
| effortless, no-makeup makeup, second-skin | cake, mask, mattify, oil-control |
| your skin, your tint, your routine | consumers, users, females |

### Emoji
**No.** Tintelle does not use emoji in product copy, navigation, or marketing. Social captions may use **one** at most (a sparkle ✨ or a peach 🍑 max). Never in the product UI.

### Examples (lifted from the brand blueprint)
- Hero: `Skincare that shows. / Color that cares.`
- Eyebrow: `TINTED SKINCARE, REDEFINED`
- Subhead: `Tinted skincare-makeup hybrids with real ingredients that deliver effortless, skin-first color.`
- Trust banner: `Dermatologist Tested · Clean & Vegan · 30-Day Shade Match`
- Newsletter: `Join the Tintelle Community. Get early access to drops, shade guides, and skin-first rituals.`
- Footer line: `Skincare that shows. Color that cares.`

---

## VISUAL FOUNDATIONS

### Colors
The palette is **warm-neutral, never cool**. Every background is a tinted off-white (cream / ivory) — *never pure `#FFF`*, *never pure `#000`*. Headings are deep mauve (`#6B4C4C`). Body is charcoal (`#2D2926`). Tintelle Blush (`#D4A0A0`) is the brand color and lives on primary CTAs. Champagne Gold (`#C9A96E`) is reserved for star ratings, sale badges, and rare luxury moments.

Pair `--warm-cream` and `--soft-ivory` for alternating section bands. Never put a pure-white card on cream — use either an ivory bg with a 1px `--cloud` border, or a true white card with the same border.

### Type
Two families, no exceptions:
- **Playfair Display** (serif, weight 500, slight negative tracking) — every heading, the wordmark, the logo, prices.
- **Inter** (sans, weights 300/400/500) — every other piece of running text, navigation, buttons, product meta.
- Italic Playfair on the second half of two-clause headlines is a Tintelle signature: `Skincare that shows. *Color that cares.*`

### Spacing & rhythm
Generous. Sections breathe at `py: 64–96px`. Container max-width `1280px` with `1.5rem` gutter. Eyebrow → headline → lede → CTA stacks at `12 / 24 / 24 / 32` between elements. Cards have at least `20–24px` of internal padding.

### Backgrounds
- **Solid warm-tone bands.** Alternate `--soft-ivory` and `--warm-cream` between sections.
- **Full-bleed editorial photography** for heroes — soft fabrics, marble, single roses, products in raking light. Always warm-toned, soft-shadowed, never cool blue light.
- **No gradients.** No mesh blobs. No noise textures. The brand is editorial, not Web3.
- **No emoji backgrounds. No illustrations.** Tintelle is photography-led.

### Borders & dividers
Hairline `1px solid var(--cloud)` for product cards and inputs. Bordered button outlines use `1px solid var(--deep-mauve)` and invert on hover. Inputs are flat, square corners, with a `rgba(--deep-mauve / 30%)` border.

### Corner radii
**Sharp.** `--radius` is `0.25rem` and rarely used. Buttons and inputs are `rounded-none` (square). Cards are square. The only round shape in the system is the **circular concern thumbnail** in `ShopByConcern` (full pill / circle).

### Shadows
Almost none. Rely on the warm-on-warm color contrast and 1px borders. When elevation IS needed (cart drawer, modals): a single soft warm shadow — `0 12px 40px rgba(107, 76, 76, 0.06)`. Never use a black drop shadow.

### Hover states
- Links / nav: color shift `--deep-mauve` → `--tintelle-blush`, `transition-colors 300ms`.
- Primary buttons: `bg-primary` → `bg-primary/90` (a touch darker).
- Outline buttons: invert — border stays, fill becomes `--deep-mauve`, text becomes `--bg`.
- Product cards: `border-color` shifts from `--cloud` → `--primary/40`; the inner `<img>` scales to `1.03` over `700ms ease-out`.
- Concern thumbs: scale `1.05` over `500ms`.

### Press / active states
Subtle opacity dip (`opacity: 0.92`) — no scale-down, no color flash. Tintelle doesn't bounce.

### Animation
- Sole entrance animation: `animate-fade-up` — 8px translateY + opacity, `600ms ease-out`. Used once on the hero.
- Image-zoom on product hover: `transition-transform 700ms`.
- Color hovers: `300ms`.
- Accordion: `200ms ease-out`.
- **No bounces. No spring. No parallax. No ScrollTrigger.** Tintelle moves like silk falling.

### Transparency & blur
- Sticky header: `bg-background/85` + `backdrop-blur-md`. The only blur in the system.
- Modals/drawers use solid `--bg-card` + `--bg-overlay` scrim (`rgba(45, 41, 38, 0.45)`).

### Imagery direction
Warm peach / cream / ivory tones. Soft natural light, raking shadows. White marble, peach silk, single rosebud, frosted glass bottles with rose-gold caps. No people in the photography library here, but on-brand: women 22–38, no-makeup makeup, natural light, never harsh studio.

### Layout grids
12-col fluid grid, container `max-w: 80rem` (1280px), `px: 1.5rem`. Hero and Routine sections are 2-up split (`grid-cols-2`, `gap: 4rem`). Product grids are 3-up (`grid-cols-3`, `gap: 2rem`). Concern thumbs are 4-up (`grid-cols-4`, `gap: 3rem`).

### What to avoid
- Pure white (`#FFFFFF`) backgrounds. Use `--soft-ivory`.
- Pure black text. Use `--charcoal`.
- Bluish or purple gradients.
- Drop shadows. Especially harsh ones.
- Round buttons / large border radii.
- Emoji in product copy.
- Sans-serif headlines.
- Hand-drawn SVG illustrations in place of real photography.

---

## ICONOGRAPHY

The Tintelle storefront uses **Lucide** icons exclusively (it ships with `lucide-react` in the codebase). They're thin (`strokeWidth: 1.5`), outlined, and tonally calm — perfect against the warm palette.

### Where icons appear
| Surface | Icon | Usage |
|---|---|---|
| Header | `Search`, `User` | Tap targets (h-5 w-5, in `--deep-mauve`) |
| Header | `ShoppingBag` | Cart trigger |
| Trust banner | `ShieldCheck`, `Leaf`, `Sparkles` | One per benefit, h-8 w-8, color `--accent` |
| Buttons (loading) | `Loader2` | with `animate-spin` |
| Stars / ratings | filled star glyph | color `--champagne-gold` |

### Rules
- **Stroke only.** No filled icons except the rating star.
- **`strokeWidth: 1.5`.** Never thinner; the brand is warm, not wiry.
- **Color:** icons inherit `--fg-strong` (deep mauve) by default; `--accent` (champagne gold) for trust-banner emphasis; `--primary` on hover.
- **Sizes:** `h-5 w-5` (UI chrome), `h-6 w-6` (inline), `h-8 w-8` (trust-banner feature icons).
- **No emoji as iconography.** Anywhere.
- **No unicode bullets** — use real `<svg>` glyphs or Lucide.

### Loading Lucide
The kit assumes Lucide is loaded. For HTML artifacts, drop in:
```html
<script src="https://unpkg.com/lucide@latest"></script>
<script>lucide.createIcons();</script>
```
Or use specific SVGs from `https://unpkg.com/lucide-static/icons/<name>.svg`.

If a substitution is ever needed, **Heroicons (outline, 1.5px)** is the closest visual cousin.

---

## Caveats & substitutions

- **Fonts** are loaded from Google Fonts (Playfair Display + Inter). No `.ttf` files are vendored — both families are reliable on Google Fonts and the Tintelle codebase loads them via the same CDN. If you need them offline, ask and I'll vendor them.
- **Logo:** the master wordmark has `BEAUTY` underneath in small Inter caps. The storefront codebase only uses the `TINTELLE` half — both treatments are valid; pick by context.
- **Product photography is AI-generated** (in the original codebase). The text on the bottles in `product-skin-tint.jpg` is illegible — that's a known artifact, not a real label. Use these as mood references, not final retail assets.
