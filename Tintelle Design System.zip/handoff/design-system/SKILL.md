---
name: tintelle-design
description: Use this skill to generate well-branded interfaces and assets for Tintelle (a premium D2C tinted skincare-makeup hybrid brand — "Skincare that shows. Color that cares."), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick orientation
- `README.md` — full brand context, content rules, visual foundations, iconography
- `colors_and_type.css` — drop-in CSS variables (colors, type, spacing, radii, shadows, easings)
- `assets/` — logo, hero, product photography
- `ui_kits/storefront/` — pixel-faithful storefront recreation; lift components from `components/*.jsx`
- `preview/` — atomic specimen cards (colors, type, components) — useful as reference

## The shortest version of the brand
- Warm, ingredient-literate, intimate. Glossier × Rhode × a French accent.
- Deep mauve `#6B4C4C` headings, charcoal `#2D2926` body, blush `#D4A0A0` CTAs.
- Backgrounds are `#FBF8F4` (ivory) and `#F5EDE3` (cream) — never pure white.
- Playfair Display headings, Inter body. Sentence-case headlines, UPPERCASE 0.3em-tracked eyebrows.
- Square corners. Hairline `#E8E2DC` borders. Soft warm shadows only, never black.
- Lucide icons, stroke-1.5. No emoji. No gradients. No bouncy animation.
