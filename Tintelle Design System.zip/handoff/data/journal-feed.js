// Tintelle Journal — feed shape modeled after a real headless CMS payload.
// Each post is the kind of object you'd get back from /api/posts on Contentful,
// Sanity, or Shopify Storefront API: id, slug, type, status, dates, author, hero,
// taxonomy, SEO, and a body of typed blocks (heading / paragraph / image / quote / list).
window.JOURNAL_FEED = {
  meta: {
    site: "tintelle.com",
    feed: "/journal/feed.json",
    generatedAt: "2026-04-22T14:08:00Z",
    total: 6,
    perPage: 9
  },
  categories: [
    { slug: "ritual",       name: "Ritual",       count: 2 },
    { slug: "ingredients",  name: "Ingredients",  count: 1 },
    { slug: "shade",        name: "Shade",        count: 1 },
    { slug: "skin-health",  name: "Skin Health",  count: 1 },
    { slug: "behind",       name: "Behind",       count: 1 }
  ],
  authors: {
    "naomi-tahir":    { name: "Naomi Tahir",    role: "Founder & Editor", avatar: null },
    "dr-ines-rivera": { name: "Dr. Inés Rivera", role: "Lead Cosmetic Chemist", avatar: null },
    "yuki-mori":      { name: "Yuki Mori",      role: "Senior Beauty Editor", avatar: null }
  },
  posts: [
    {
      id: "post_001",
      slug: "the-90-second-face",
      type: "article",
      status: "published",
      title: "The 90-second face: Tintelle\u2019s morning shortcut",
      subtitle: "Three products, one wash of color, and skin that still looks like skin.",
      excerpt: "The most useful makeup ritual I know takes ninety seconds. It happens between coffee and the front door, on a morning that started with one too many snoozes.",
      category: "ritual",
      tags: ["routine","skin-tint","cheek-tint","lip-tint","everyday"],
      hero: { src: "tintelle-hero.jpg", alt: "Peach silk on a warm marble surface", credit: "Tintelle Studio" },
      author: "naomi-tahir",
      publishedAt: "2026-04-18T09:00:00Z",
      updatedAt:   "2026-04-18T09:00:00Z",
      readTime: 4,
      featured: true,
      seo: {
        title: "The 90-second face | Tintelle Journal",
        description: "A three-product, ninety-second face from Tintelle. Skin Tint, Cheek Tint, Lip Tint — built for actual mornings.",
        ogImage: "tintelle-hero.jpg"
      },
      relatedProductIds: ["skin-tint","cheek-tint","lip-tint","routine"],
      body: [
        { type: "paragraph", text: "The most useful makeup ritual I know takes ninety seconds. It happens between coffee and the front door, on a morning that started with one too many snoozes. Three products, eight blinks, done." },
        { type: "paragraph", text: "This is what I do." },
        { type: "heading", level: 2, text: "1. Skin Tint, in five places." },
        { type: "paragraph", text: "One pump, dotted on the forehead, two cheeks, nose, and chin. Press in with clean fingers \u2014 never wipe \u2014 and let the warmth of your skin do the work. The mineral SPF blends easier when it\u2019s a little warm." },
        { type: "heading", level: 2, text: "2. Cheek Tint, before powder." },
        { type: "paragraph", text: "A pea-sized dot at the apple, blended up toward the temple. The squalane keeps it dewy, so you don\u2019t need a setting step." },
        { type: "heading", level: 2, text: "3. Lip Tint, on the way out." },
        { type: "paragraph", text: "Apply in the elevator. The peptides keep working for hours; you\u2019ll feel the plump before you feel the color settle." },
        { type: "quote", text: "That\u2019s the routine. It\u2019s not less makeup \u2014 it\u2019s less effort. The skin is doing the work." }
      ]
    },
    {
      id: "post_002",
      slug: "why-peptides-belong-in-your-lip-balm",
      type: "article",
      status: "published",
      title: "Why peptides belong in your lip balm (and not just serums)",
      subtitle: "The science behind a softer pout.",
      excerpt: "Peptides have been the headline of every face serum for a decade. Here\u2019s why they finally made it into Tintelle\u2019s lip tint \u2014 and what they actually do.",
      category: "ingredients",
      tags: ["peptides","lip-tint","science","ingredients-deep-dive"],
      hero: { src: "product-lip-tint.jpg", alt: "Peptide Lip Tint product shot", credit: "Tintelle Studio" },
      author: "dr-ines-rivera",
      publishedAt: "2026-03-28T14:30:00Z",
      updatedAt:   "2026-03-29T08:15:00Z",
      readTime: 6,
      featured: false,
      seo: {
        title: "Peptides in lip balm \u2014 the science | Tintelle Journal",
        description: "Cosmetic chemist Dr. In\u00e9s Rivera explains how palmitoyl tripeptide-1 strengthens the lip barrier and why it works in tinted formulas.",
        ogImage: "product-lip-tint.jpg"
      },
      relatedProductIds: ["lip-tint","skin-tint"],
      body: [
        { type: "paragraph", text: "Peptides have been the headline of every face serum for a decade. They\u2019re the reason your night cream costs more than your moisturizer. So why are most lip products still relying on petrolatum and a prayer?" },
        { type: "heading", level: 2, text: "Lips age faster than the rest of the face." },
        { type: "paragraph", text: "The skin on the vermilion border is three to five cell layers thinner than your cheek. It has fewer melanocytes (so less UV protection), almost no sebaceous glands (so less natural lipid replenishment), and it bends and stretches all day." },
        { type: "paragraph", text: "Translation: lips need more help, sooner. By 35, most people have visible volume loss and barrier disruption \u2014 the chronic chap that no balm seems to fix." },
        { type: "heading", level: 2, text: "What palmitoyl tripeptide-1 actually does." },
        { type: "paragraph", text: "It\u2019s a signaling peptide \u2014 a tiny chain of three amino acids attached to a fatty acid for skin penetration. When it reaches the dermis, it tells fibroblasts to produce more collagen and elastin. In a 12-week study, subjects saw a 31% reduction in lip-line depth and a 17% increase in vermilion volume." },
        { type: "list", style: "unordered", items: [
          "Reduces transepidermal water loss \u2014 lips stay hydrated through coffee and conversation.",
          "Strengthens the barrier so color glides instead of feathering.",
          "Works under and through pigment \u2014 the tint is the delivery system, not a competitor."
        ] },
        { type: "quote", text: "A lip tint with peptides isn\u2019t a stunt. It\u2019s the most efficient way to feed your lips while you wear color." }
      ]
    },
    {
      id: "post_003",
      slug: "finding-your-skin-tint",
      type: "article",
      status: "published",
      title: "Finding your skin tint, without trying every shade",
      subtitle: "A field guide to the hidden math of undertone.",
      excerpt: "Twelve shades sounds like a lot. It is and it isn\u2019t. The trick is reading two things on your own face: depth, and undertone. Here\u2019s how.",
      category: "shade",
      tags: ["shade-finder","undertone","skin-tint","education"],
      hero: { src: "product-skin-tint.jpg", alt: "Skin Tint shade lineup", credit: "Tintelle Studio" },
      author: "yuki-mori",
      publishedAt: "2026-03-12T11:00:00Z",
      updatedAt:   "2026-03-12T11:00:00Z",
      readTime: 5,
      featured: false,
      seo: {
        title: "Find your shade \u2014 Tintelle Skin Tint",
        description: "Two questions about your skin will narrow twelve shades to two. A practical guide to undertone from Tintelle\u2019s editor.",
        ogImage: "product-skin-tint.jpg"
      },
      relatedProductIds: ["skin-tint","eye-serum"],
      body: [
        { type: "paragraph", text: "Twelve shades sounds like a lot. It is and it isn\u2019t. The trick is reading two things on your own face: depth, and undertone." },
        { type: "heading", level: 2, text: "Depth is the easy part." },
        { type: "paragraph", text: "Depth is just \u201chow light or deep is your skin?\u201d Stand by a window in morning light \u2014 not bathroom light, which lies. Compare your jaw to white paper. A shade that disappears into the jawline is your match. If it pinks up your nose or dulls your cheeks, you\u2019ve gone too light or too deep." },
        { type: "heading", level: 2, text: "Undertone is the actual decision." },
        { type: "list", style: "unordered", items: [
          "Warm \u2014 your veins look greenish, gold jewelry flatters, you tan before you burn.",
          "Cool \u2014 veins look blueish, silver flatters, you burn before you tan.",
          "Neutral \u2014 veins read teal, both metals work, you tan slowly."
        ] },
        { type: "paragraph", text: "Tintelle Skin Tint is offered in W (warm), C (cool), and N (neutral) variants for each depth. Six depths \u00d7 two undertones each = twelve shades, no shade fatigue." }
      ]
    },
    {
      id: "post_004",
      slug: "spf-and-tint-summer-routine",
      type: "article",
      status: "published",
      title: "SPF + tint: the only summer routine you need",
      subtitle: "The lazy edit, by way of the dermatologist.",
      excerpt: "Once it gets above 75\u00b0F, my routine collapses to two products. Here\u2019s why that\u2019s actually the right call.",
      category: "skin-health",
      tags: ["spf","summer","routine","sun-care"],
      hero: { src: "product-cheek-tint.jpg", alt: "Glow Cheek Tint melted on a warm marble surface", credit: "Tintelle Studio" },
      author: "naomi-tahir",
      publishedAt: "2026-02-21T10:00:00Z",
      updatedAt:   "2026-02-21T10:00:00Z",
      readTime: 3,
      featured: false,
      seo: {
        title: "SPF + tint summer routine | Tintelle Journal",
        description: "A two-product summer face from Tintelle: mineral SPF skin tint and a melted cheek tint. That\u2019s the routine.",
        ogImage: "product-cheek-tint.jpg"
      },
      relatedProductIds: ["skin-tint","cheek-tint"],
      body: [
        { type: "paragraph", text: "Once it gets above 75\u00b0F, my routine collapses to two products: Skin Tint SPF 30 and Glow Cheek Tint. That\u2019s it. That\u2019s the routine." },
        { type: "heading", level: 2, text: "Why mineral SPF first." },
        { type: "paragraph", text: "Chemical SPFs need 15\u201320 minutes to bind. Mineral filters \u2014 zinc oxide, titanium dioxide \u2014 work immediately, sit on the surface, and reflect UV. They\u2019re also gentler on reactive skin and reef-safer." },
        { type: "heading", level: 2, text: "Why a cream blush in summer." },
        { type: "paragraph", text: "Powder grabs onto sweat and starts looking patchy by lunch. A squalane-based cream blush melts into skin and doesn\u2019t lift when you wipe your forehead. Tap it on with your fingers \u2014 brushes are a humidity casualty." },
        { type: "quote", text: "Two products. Five minutes. SPF 30 doing the actual work." }
      ]
    },
    {
      id: "post_005",
      slug: "inside-the-lab",
      type: "article",
      status: "published",
      title: "Inside the lab where Tintelle is made",
      subtitle: "Three rooms, twenty people, and a lot of beakers.",
      excerpt: "Our lab is a refurbished textile mill in Montr\u00e9al. Here\u2019s a tour, with the chemists who actually formulate the things you put on your face.",
      category: "behind",
      tags: ["behind-the-scenes","manufacturing","montreal","team"],
      hero: { src: "tintelle-routine.jpg", alt: "The Tintelle Routine bundle on linen", credit: "Tintelle Studio" },
      author: "yuki-mori",
      publishedAt: "2026-02-04T13:00:00Z",
      updatedAt:   "2026-02-04T13:00:00Z",
      readTime: 7,
      featured: false,
      seo: {
        title: "Inside the Tintelle lab",
        description: "A tour of Tintelle\u2019s Montr\u00e9al formulation lab \u2014 three rooms, twenty chemists, small batches.",
        ogImage: "tintelle-routine.jpg"
      },
      relatedProductIds: ["routine"],
      body: [
        { type: "paragraph", text: "Our lab is a refurbished textile mill in Montr\u00e9al, three blocks from the river. The walls are still brick. The floors are still hardwood, mostly. The equipment is decidedly not 1900s." },
        { type: "heading", level: 2, text: "The benchroom." },
        { type: "paragraph", text: "Twelve fume hoods, four homogenizers, and a wall of raw-material drawers organized like a tea library. This is where formulas start \u2014 in 100 mL beakers, with chemists who have made between six and forty rounds before they pass quality control." },
        { type: "heading", level: 2, text: "The pilot kitchen." },
        { type: "paragraph", text: "Once a formula is locked, it gets scaled to 5 L, then 50 L. Roughly half don\u2019t survive the scale-up; the textures change, or the suspension fails. Those go back to the bench." },
        { type: "heading", level: 2, text: "The fill line." },
        { type: "paragraph", text: "Small batch, semi-automatic, finishes 1,200 units an hour. Slow by industry standards \u2014 fast enough for us." }
      ]
    },
    {
      id: "post_006",
      slug: "layer-color-cheek-or-lip",
      type: "article",
      status: "published",
      title: "How to layer color: cheek before lip, or lip before cheek?",
      subtitle: "A small ordering question with a real answer.",
      excerpt: "There is a correct order. It\u2019s not what you think, and it has to do with how pigment binds to a wet surface.",
      category: "ritual",
      tags: ["technique","layering","application"],
      hero: { src: "product-eye-serum.jpg", alt: "Tinted Eye Serum on warm linen", credit: "Tintelle Studio" },
      author: "yuki-mori",
      publishedAt: "2026-01-18T10:30:00Z",
      updatedAt:   "2026-01-18T10:30:00Z",
      readTime: 4,
      featured: false,
      seo: {
        title: "How to layer cheek and lip color | Tintelle Journal",
        description: "There\u2019s a right order to applying cream blush and lip tint. Here it is, with the chemistry behind it.",
        ogImage: "product-eye-serum.jpg"
      },
      relatedProductIds: ["cheek-tint","lip-tint","eye-serum"],
      body: [
        { type: "paragraph", text: "There is a correct order. It\u2019s not what you think, and it has to do with how pigment binds to a wet surface." },
        { type: "heading", level: 2, text: "Cheek first." },
        { type: "paragraph", text: "Apply cheek tint while skin tint is still slightly tacky. The pigment grabs the emollients in the skin tint, blends in, and dries down with it. Wait too long and the cheek sits on top instead of melting in." },
        { type: "heading", level: 2, text: "Lip last." },
        { type: "paragraph", text: "Lip tint goes on dry, after everything else has set. The peptides in the formula need time to bind to the lip\u2019s lipid layer; if you apply too early, you re-emulsify whatever\u2019s already there." }
      ]
    }
  ]
};
