# Tintelle Storefront — Design Handoff Bundle

This repository is a **complete, working design specification** for the Tintelle DTC clean-beauty storefront. Every page, every component, every line of CSS and JS is here. It is the source-of-truth for re-implementation in any production stack (Shopify Hydrogen, Next.js, Remix, Lovable, etc.).

You can open `index.html` directly in a browser to view the live design — no build step, no install. Every page is functional: navigation, cart, wishlist, search, checkout flow, journal, order tracking, subscriptions.

---

## Quick start

```bash
# Just open the file
open index.html
```

Or serve it (for clean URLs, optional):
```bash
npx serve .
```

That's it. The site uses inline-Babel React from CDN, so there's nothing to install.

---

## What's inside

```
handoff/
├── index.html              # Homepage — entry point
├── colors_and_type.css     # Design tokens (colors, type, spacing, radii)
├── components/             # 12 React components, shared across pages
│   ├── Chrome.jsx          # ⭐ Header + Footer + cart store + wishlist store + product catalog
│   ├── Hero.jsx
│   ├── Bestsellers.jsx
│   ├── ProductCard.jsx
│   ├── ShopByConcern.jsx
│   ├── RoutineUpsell.jsx
│   ├── TrustBanner.jsx
│   ├── CartDrawer.jsx
│   ├── App.jsx             # Original homepage composition (used by index.html)
│   ├── AnnouncementBar.jsx
│   ├── Header.jsx          # Original (Chrome.jsx PageHeader supersedes for inner pages)
│   └── Footer.jsx          # Original (Chrome.jsx PageFooter supersedes for inner pages)
│
├── pages/                  # 16 inner pages
│   ├── shop.html           # Collection / category grid with filters
│   ├── pdp.html            # Product detail (?id=skin-tint, etc.)
│   ├── cart.html           # 4-step checkout (cart → shipping → payment → confirmation)
│   ├── account.html        # Sign in / sign up / member dashboard
│   ├── wishlist.html       # Saved products
│   ├── search.html         # Live search across products + journal + help
│   ├── subscribe.html      # Subscribe & save flow
│   ├── track.html          # Order tracking with timeline (try TT-10428 / TT-10311)
│   ├── about.html          # Brand story
│   ├── journal.html        # Editorial index (reads data/journal-feed.js)
│   ├── post.html           # Article view (?slug=...)
│   ├── contact.html
│   ├── faq.html
│   ├── shipping.html       # Shipping & returns
│   ├── privacy.html        # Privacy policy
│   └── terms.html          # Terms & conditions
│
├── data/
│   └── journal-feed.js     # Realistic CMS-shaped feed (window.JOURNAL_FEED)
│
├── assets/                 # Product photography, hero, logo
│   ├── tintelle-logo.png
│   ├── tintelle-hero.jpg
│   ├── tintelle-routine.jpg
│   ├── product-skin-tint.jpg
│   ├── product-lip-tint.jpg
│   ├── product-cheek-tint.jpg
│   └── product-eye-serum.jpg
│
├── design-system/          # The design system, documented
│   ├── README.md           # Full brand + system documentation
│   ├── SKILL.md            # How to use this design system
│   └── preview/            # 17 HTML cards (colors, type, spacing, components)
│
└── LOVABLE_BRIEF.md        # ⭐ Read this first if you're rebuilding with an AI tool
```

---

## How it works

**No build step.** Every page loads:
1. `colors_and_type.css` — design tokens as CSS custom properties (`--primary`, `--font-serif`, etc.)
2. React 18 + ReactDOM + Babel from unpkg (pinned versions)
3. `components/Chrome.jsx` — the shared header, footer, and stores
4. An inline `<script type="text/babel">` block that defines and renders the page

**Shared state** lives in `components/Chrome.jsx`:
- `window.cartStore` — localStorage-backed cart (`get/add/setQty/remove/count`)
- `window.wishlistStore` — localStorage-backed wishlist (`get/has/toggle/remove`)
- `window.PRODUCTS` — the product catalog (5 SKUs)
- `useCart()` / `useWishlist()` — React hooks that subscribe to those stores
- `pathPrefix()` / `assetUrl()` — path helpers so the same components work from `index.html` or `pages/*.html`

**Routing** is plain `<a href>` between HTML files. Query strings drive variants:
- `pdp.html?id=lip-tint`
- `post.html?slug=the-90-second-face`
- `journal.html?category=ritual`
- `search.html?q=peptide`
- `track.html?order=TT-10428`

**Cart & wishlist persist across pages** via localStorage with a `cart:change` / `wishlist:change` custom event for cross-tab sync.

---

## Design tokens

All in `colors_and_type.css`:

```css
--bg: #FBF8F4;            /* Soft Ivory */
--warm-cream: #F5EFE6;    /* Section backgrounds */
--primary: #C97D7D;       /* Rosé Mauve — CTAs, links, accents */
--deep-mauve: #6B4C4C;    /* Headlines, primary text */
--rose-taupe: #9B7B7B;    /* Secondary text */
--cloud: #E8E2DC;         /* Borders, dividers */
--accent: #E8A598;        /* Coral — sale tags, ratings */

--font-serif: 'Cormorant Garamond', serif;
--font-sans:  'Inter', sans-serif;
```

See `design-system/preview/*.html` for visual swatches of every token.

---

## Pages — at a glance

| Page | Path | Notes |
|---|---|---|
| Home | `index.html` | Hero, bestsellers, shop-by-concern, routine bundle, trust banner |
| Shop | `pages/shop.html` | Category filter, sort, product grid |
| PDP | `pages/pdp.html?id=...` | Gallery, shade picker, ingredients accordion, cross-sell, wishlist heart |
| Cart | `pages/cart.html` | 4-step flow with localStorage persistence |
| Account | `pages/account.html` | Sign in / sign up / dashboard tabs |
| Wishlist | `pages/wishlist.html` | Saved items with move-to-bag |
| Search | `pages/search.html?q=...` | Multi-section live search, debounced |
| Subscribe | `pages/subscribe.html` | Product picker, frequency, summary, FAQ |
| Track | `pages/track.html` | Order lookup. Demo IDs: `TT-10428`, `TT-10311` |
| About | `pages/about.html` | Story + 4 pillars + sustainability |
| Journal | `pages/journal.html` | Reads `data/journal-feed.js` |
| Post | `pages/post.html?slug=...` | Block renderer for `paragraph/heading/quote/list/image` |
| Contact | `pages/contact.html` | Channels + form |
| FAQ | `pages/faq.html` | Searchable, 4 categories |
| Shipping | `pages/shipping.html` | Rate table + Shade Match Guarantee |
| Privacy | `pages/privacy.html` | Sticky-TOC, 10 sections |
| Terms | `pages/terms.html` | Sticky-TOC, 14 sections |

---

## Caveats for production

1. **Inline Babel is for design fidelity, not production.** Re-compile components in your real stack. The JSX is hand-written, framework-agnostic React — it ports to Next.js / Hydrogen / Remix without rewrites.
2. **Forms are mocked.** Account login, contact, newsletter — all `e.preventDefault()`. Wire to your backend.
3. **Order tracking uses two demo orders** (`SAMPLE_ORDERS` in `pages/track.html`). Replace with `/api/orders/:id` against your fulfillment system. The data shape is realistic — keep it.
4. **Journal feed is local.** `window.JOURNAL_FEED` in `data/journal-feed.js` mirrors a CMS payload (Contentful/Sanity/Storefront API shape). Replace with a real fetch.
5. **Legal copy is realistic boilerplate** — have a lawyer review Privacy and Terms before launch.
6. **Address `1280 Hayes Street, San Francisco`** and emails (`hi@tintelle.com`, etc.) are placeholders.

---

## License

Design and copy © 2026 Tintelle. Code is provided for the purpose of re-implementation by the project owner.
